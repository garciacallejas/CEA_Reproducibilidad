# GHRSP
A workshop introducing GitHub with RStudio and simple R package development

[https://frousseu.github.io/GHRSP](https://frousseu.github.io/GHRSP)

## GitHub

Here we will introduce GitHub

## R Packages

Here we will introduce building really small R packages

